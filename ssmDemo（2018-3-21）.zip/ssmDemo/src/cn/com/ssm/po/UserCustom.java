package cn.com.ssm.po;
/**
 * 用户的扩展类
 * @author lenovo
 *
 */
public class UserCustom extends User{
	//

}
