package cn.com.ssm.mapper;

import cn.com.ssm.po.User;


public interface UserMapperCustom {

		//登录
		public void login(String user_name, String user_pass);

		//注册
		public void regist(User user);

}
