package test;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.com.ssm.mapper.DemandMapperCustom;
import cn.com.ssm.po.Demand;

public class DemandMapperTest {
	private ApplicationContext applicationContext;
	private DemandMapperCustom demandMapperCustom;
	
	@Before
	public void setUp(){
		applicationContext=(ApplicationContext) new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		demandMapperCustom= (DemandMapperCustom) applicationContext.getBean("demandMapperCustom");
	}
	 
	//用户发布需求
	@Test
	public void addDemandTest(){
		Demand demand=new Demand();
		demand.setDemandId(5);
		demand.setUserId(3);
		demand.setDemandTitle("用户发布的第5条需求");
		demand.setDemandDetail("这是用户发布的第5条需求");
		demand.setDemandType("已中标");
		Date date = new Date(2017,3,19);
		demand.setDemandTime(date);
		demandMapperCustom.addDemand(demand);
	}
	
	

}
