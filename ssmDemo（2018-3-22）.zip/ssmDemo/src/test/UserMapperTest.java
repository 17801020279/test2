package test;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.com.ssm.mapper.UserMapperCustom;
import cn.com.ssm.po.User;

public class UserMapperTest {
	private ApplicationContext applicationContext;
	private UserMapperCustom  userMapperCustom;
	
	@Before
	public void setUp(){
		applicationContext=(ApplicationContext) new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		userMapperCustom= (UserMapperCustom) applicationContext.getBean("userMapperCustom");
	}
	 
	//注册
	@Test
	public void registTest(){
		User user=new User();
		user.setUserId(3453);
		user.setUserName("1239871111111111");
		user.setUserPass("1234511111111111");
		userMapperCustom.registUser(user);
		System.out.println(user.getUserName()+"注册成功");
	}
	
	
	//登录
	@Test
	public void loginTest(){
		userMapperCustom.loginUser("111","111");
		System.out.println(userMapperCustom);
		System.out.println("用户登录成功");
	}
	
	
	
	

}
