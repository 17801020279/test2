package cn.com.ssm.po;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class DemandExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public DemandExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andDemandIdIsNull() {
            addCriterion("demand_id is null");
            return (Criteria) this;
        }

        public Criteria andDemandIdIsNotNull() {
            addCriterion("demand_id is not null");
            return (Criteria) this;
        }

        public Criteria andDemandIdEqualTo(Integer value) {
            addCriterion("demand_id =", value, "demandId");
            return (Criteria) this;
        }

        public Criteria andDemandIdNotEqualTo(Integer value) {
            addCriterion("demand_id <>", value, "demandId");
            return (Criteria) this;
        }

        public Criteria andDemandIdGreaterThan(Integer value) {
            addCriterion("demand_id >", value, "demandId");
            return (Criteria) this;
        }

        public Criteria andDemandIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("demand_id >=", value, "demandId");
            return (Criteria) this;
        }

        public Criteria andDemandIdLessThan(Integer value) {
            addCriterion("demand_id <", value, "demandId");
            return (Criteria) this;
        }

        public Criteria andDemandIdLessThanOrEqualTo(Integer value) {
            addCriterion("demand_id <=", value, "demandId");
            return (Criteria) this;
        }

        public Criteria andDemandIdIn(List<Integer> values) {
            addCriterion("demand_id in", values, "demandId");
            return (Criteria) this;
        }

        public Criteria andDemandIdNotIn(List<Integer> values) {
            addCriterion("demand_id not in", values, "demandId");
            return (Criteria) this;
        }

        public Criteria andDemandIdBetween(Integer value1, Integer value2) {
            addCriterion("demand_id between", value1, value2, "demandId");
            return (Criteria) this;
        }

        public Criteria andDemandIdNotBetween(Integer value1, Integer value2) {
            addCriterion("demand_id not between", value1, value2, "demandId");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNull() {
            addCriterion("user_id is null");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNotNull() {
            addCriterion("user_id is not null");
            return (Criteria) this;
        }

        public Criteria andUserIdEqualTo(Integer value) {
            addCriterion("user_id =", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotEqualTo(Integer value) {
            addCriterion("user_id <>", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThan(Integer value) {
            addCriterion("user_id >", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("user_id >=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThan(Integer value) {
            addCriterion("user_id <", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThanOrEqualTo(Integer value) {
            addCriterion("user_id <=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdIn(List<Integer> values) {
            addCriterion("user_id in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotIn(List<Integer> values) {
            addCriterion("user_id not in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdBetween(Integer value1, Integer value2) {
            addCriterion("user_id between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotBetween(Integer value1, Integer value2) {
            addCriterion("user_id not between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andDemandTitleIsNull() {
            addCriterion("demand_title is null");
            return (Criteria) this;
        }

        public Criteria andDemandTitleIsNotNull() {
            addCriterion("demand_title is not null");
            return (Criteria) this;
        }

        public Criteria andDemandTitleEqualTo(String value) {
            addCriterion("demand_title =", value, "demandTitle");
            return (Criteria) this;
        }

        public Criteria andDemandTitleNotEqualTo(String value) {
            addCriterion("demand_title <>", value, "demandTitle");
            return (Criteria) this;
        }

        public Criteria andDemandTitleGreaterThan(String value) {
            addCriterion("demand_title >", value, "demandTitle");
            return (Criteria) this;
        }

        public Criteria andDemandTitleGreaterThanOrEqualTo(String value) {
            addCriterion("demand_title >=", value, "demandTitle");
            return (Criteria) this;
        }

        public Criteria andDemandTitleLessThan(String value) {
            addCriterion("demand_title <", value, "demandTitle");
            return (Criteria) this;
        }

        public Criteria andDemandTitleLessThanOrEqualTo(String value) {
            addCriterion("demand_title <=", value, "demandTitle");
            return (Criteria) this;
        }

        public Criteria andDemandTitleLike(String value) {
            addCriterion("demand_title like", value, "demandTitle");
            return (Criteria) this;
        }

        public Criteria andDemandTitleNotLike(String value) {
            addCriterion("demand_title not like", value, "demandTitle");
            return (Criteria) this;
        }

        public Criteria andDemandTitleIn(List<String> values) {
            addCriterion("demand_title in", values, "demandTitle");
            return (Criteria) this;
        }

        public Criteria andDemandTitleNotIn(List<String> values) {
            addCriterion("demand_title not in", values, "demandTitle");
            return (Criteria) this;
        }

        public Criteria andDemandTitleBetween(String value1, String value2) {
            addCriterion("demand_title between", value1, value2, "demandTitle");
            return (Criteria) this;
        }

        public Criteria andDemandTitleNotBetween(String value1, String value2) {
            addCriterion("demand_title not between", value1, value2, "demandTitle");
            return (Criteria) this;
        }

        public Criteria andDemandTypeIsNull() {
            addCriterion("demand_type is null");
            return (Criteria) this;
        }

        public Criteria andDemandTypeIsNotNull() {
            addCriterion("demand_type is not null");
            return (Criteria) this;
        }

        public Criteria andDemandTypeEqualTo(String value) {
            addCriterion("demand_type =", value, "demandType");
            return (Criteria) this;
        }

        public Criteria andDemandTypeNotEqualTo(String value) {
            addCriterion("demand_type <>", value, "demandType");
            return (Criteria) this;
        }

        public Criteria andDemandTypeGreaterThan(String value) {
            addCriterion("demand_type >", value, "demandType");
            return (Criteria) this;
        }

        public Criteria andDemandTypeGreaterThanOrEqualTo(String value) {
            addCriterion("demand_type >=", value, "demandType");
            return (Criteria) this;
        }

        public Criteria andDemandTypeLessThan(String value) {
            addCriterion("demand_type <", value, "demandType");
            return (Criteria) this;
        }

        public Criteria andDemandTypeLessThanOrEqualTo(String value) {
            addCriterion("demand_type <=", value, "demandType");
            return (Criteria) this;
        }

        public Criteria andDemandTypeLike(String value) {
            addCriterion("demand_type like", value, "demandType");
            return (Criteria) this;
        }

        public Criteria andDemandTypeNotLike(String value) {
            addCriterion("demand_type not like", value, "demandType");
            return (Criteria) this;
        }

        public Criteria andDemandTypeIn(List<String> values) {
            addCriterion("demand_type in", values, "demandType");
            return (Criteria) this;
        }

        public Criteria andDemandTypeNotIn(List<String> values) {
            addCriterion("demand_type not in", values, "demandType");
            return (Criteria) this;
        }

        public Criteria andDemandTypeBetween(String value1, String value2) {
            addCriterion("demand_type between", value1, value2, "demandType");
            return (Criteria) this;
        }

        public Criteria andDemandTypeNotBetween(String value1, String value2) {
            addCriterion("demand_type not between", value1, value2, "demandType");
            return (Criteria) this;
        }

        public Criteria andDemandDetailIsNull() {
            addCriterion("demand_detail is null");
            return (Criteria) this;
        }

        public Criteria andDemandDetailIsNotNull() {
            addCriterion("demand_detail is not null");
            return (Criteria) this;
        }

        public Criteria andDemandDetailEqualTo(String value) {
            addCriterion("demand_detail =", value, "demandDetail");
            return (Criteria) this;
        }

        public Criteria andDemandDetailNotEqualTo(String value) {
            addCriterion("demand_detail <>", value, "demandDetail");
            return (Criteria) this;
        }

        public Criteria andDemandDetailGreaterThan(String value) {
            addCriterion("demand_detail >", value, "demandDetail");
            return (Criteria) this;
        }

        public Criteria andDemandDetailGreaterThanOrEqualTo(String value) {
            addCriterion("demand_detail >=", value, "demandDetail");
            return (Criteria) this;
        }

        public Criteria andDemandDetailLessThan(String value) {
            addCriterion("demand_detail <", value, "demandDetail");
            return (Criteria) this;
        }

        public Criteria andDemandDetailLessThanOrEqualTo(String value) {
            addCriterion("demand_detail <=", value, "demandDetail");
            return (Criteria) this;
        }

        public Criteria andDemandDetailLike(String value) {
            addCriterion("demand_detail like", value, "demandDetail");
            return (Criteria) this;
        }

        public Criteria andDemandDetailNotLike(String value) {
            addCriterion("demand_detail not like", value, "demandDetail");
            return (Criteria) this;
        }

        public Criteria andDemandDetailIn(List<String> values) {
            addCriterion("demand_detail in", values, "demandDetail");
            return (Criteria) this;
        }

        public Criteria andDemandDetailNotIn(List<String> values) {
            addCriterion("demand_detail not in", values, "demandDetail");
            return (Criteria) this;
        }

        public Criteria andDemandDetailBetween(String value1, String value2) {
            addCriterion("demand_detail between", value1, value2, "demandDetail");
            return (Criteria) this;
        }

        public Criteria andDemandDetailNotBetween(String value1, String value2) {
            addCriterion("demand_detail not between", value1, value2, "demandDetail");
            return (Criteria) this;
        }

        public Criteria andDemandTimeIsNull() {
            addCriterion("demand_time is null");
            return (Criteria) this;
        }

        public Criteria andDemandTimeIsNotNull() {
            addCriterion("demand_time is not null");
            return (Criteria) this;
        }

        public Criteria andDemandTimeEqualTo(Date value) {
            addCriterionForJDBCDate("demand_time =", value, "demandTime");
            return (Criteria) this;
        }

        public Criteria andDemandTimeNotEqualTo(Date value) {
            addCriterionForJDBCDate("demand_time <>", value, "demandTime");
            return (Criteria) this;
        }

        public Criteria andDemandTimeGreaterThan(Date value) {
            addCriterionForJDBCDate("demand_time >", value, "demandTime");
            return (Criteria) this;
        }

        public Criteria andDemandTimeGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("demand_time >=", value, "demandTime");
            return (Criteria) this;
        }

        public Criteria andDemandTimeLessThan(Date value) {
            addCriterionForJDBCDate("demand_time <", value, "demandTime");
            return (Criteria) this;
        }

        public Criteria andDemandTimeLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("demand_time <=", value, "demandTime");
            return (Criteria) this;
        }

        public Criteria andDemandTimeIn(List<Date> values) {
            addCriterionForJDBCDate("demand_time in", values, "demandTime");
            return (Criteria) this;
        }

        public Criteria andDemandTimeNotIn(List<Date> values) {
            addCriterionForJDBCDate("demand_time not in", values, "demandTime");
            return (Criteria) this;
        }

        public Criteria andDemandTimeBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("demand_time between", value1, value2, "demandTime");
            return (Criteria) this;
        }

        public Criteria andDemandTimeNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("demand_time not between", value1, value2, "demandTime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}