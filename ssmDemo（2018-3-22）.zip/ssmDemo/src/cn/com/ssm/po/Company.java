package cn.com.ssm.po;

public class Company {
    private Integer comId;

    private String comName;

    private String comPass;

    private String comCeoName;

    public Integer getComId() {
        return comId;
    }

    public void setComId(Integer comId) {
        this.comId = comId;
    }

    public String getComName() {
        return comName;
    }

    public void setComName(String comName) {
        this.comName = comName == null ? null : comName.trim();
    }

    public String getComPass() {
        return comPass;
    }

    public void setComPass(String comPass) {
        this.comPass = comPass == null ? null : comPass.trim();
    }

    public String getComCeoName() {
        return comCeoName;
    }

    public void setComCeoName(String comCeoName) {
        this.comCeoName = comCeoName == null ? null : comCeoName.trim();
    }
}