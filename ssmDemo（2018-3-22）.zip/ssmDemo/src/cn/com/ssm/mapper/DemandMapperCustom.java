package cn.com.ssm.mapper;


import cn.com.ssm.po.Demand;

public interface DemandMapperCustom {
	//用户发布需求
	/*public Demand addDemand(@Param("demand_id")Integer demand_id, @Param("user_id")Integer user_id,
			@Param("demand_title")String demand_title,@Param("demand_type")String demand_type ,
			@Param("demand_detail")String demand_detail,@Param("demand_time")String demand_time);*/
	public Demand addDemand(Demand demand);

}
