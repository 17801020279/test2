package cn.com.ssm.mapper;

import org.apache.ibatis.annotations.Param;

import cn.com.ssm.po.User;


public interface UserMapperCustom {

		//登录
		public User loginUser(@Param("user_name")String user_name, @Param("user_pass")String user_pass);

		//注册
		public User registUser(User user);
		
		//修改用户信息
		public User updateUser(User user);
		
		

}
