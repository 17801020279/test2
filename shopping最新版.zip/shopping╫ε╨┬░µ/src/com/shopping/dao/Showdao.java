package com.shopping.dao;

import java.sql.*;
import java.util.*;

import com.shopping.DbUtil.DatabaseLink;
import com.shopping.bean.Goods;

public class Showdao {
	
	public  List<Goods> showBookList() throws Exception{
		List<Goods> bookList=new ArrayList<Goods>();
		try {
			DatabaseLink db = new DatabaseLink();
		    Connection conn = db.getConn();
			PreparedStatement pstate =conn.prepareStatement("select * from goods where type=? order by id");
			pstate.setNString(1, "ͼ��");
			ResultSet rs = pstate.executeQuery();
			while(rs.next()){ 
				Goods goods =new Goods();
		        goods.setId(rs.getString("id"));
		        goods.setName(rs.getString("name"));
		        goods.setType(rs.getString("type"));
		        goods.setPicture(rs.getString("picture"));
		        goods.setPrice(rs.getFloat("price"));
		        bookList.add(goods);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return bookList;
	}
	
	public  List<Goods> showFoodList() throws Exception{
		List<Goods> foodList=new ArrayList<Goods>();
		try {
			DatabaseLink db = new DatabaseLink();
		    Connection conn = db.getConn();
			PreparedStatement pstate =conn.prepareStatement("select * from goods where type=? order by id");
			pstate.setNString(1, "ʳƷ");
			ResultSet rs = pstate.executeQuery();
			while(rs.next()){ 
				Goods goods =new Goods();
		        goods.setId(rs.getString("id"));
		        goods.setName(rs.getString("name"));
		        goods.setType(rs.getString("type"));
		        goods.setPicture(rs.getString("picture"));
		        goods.setPrice(rs.getFloat("price"));
		        foodList.add(goods);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return foodList;
	}
	
	public List<Goods> showDetail(String id) throws Exception{
		List<Goods> goodsList = new ArrayList<Goods>();
		try{
			DatabaseLink db = new DatabaseLink();
			Connection conn = db.getConn();
			PreparedStatement pstate =conn.prepareStatement("select * from goods where id=? ");
			pstate.setNString(1, id);
			ResultSet rs = pstate.executeQuery();
			while(rs.next()){
				Goods goods =new Goods();
		        goods.setId(rs.getString("id"));
		        goods.setName(rs.getString("name"));
		        goods.setType(rs.getString("type"));
		        goods.setPicture(rs.getString("picture"));
		        goods.setPrice(rs.getFloat("price"));
		        goodsList.add(goods);
			}
		}catch (SQLException e){
			e.printStackTrace();
			return null;
		}
		return goodsList;
		
	}

}
