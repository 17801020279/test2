package com.shopping.dao;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.shopping.DbUtil.DatabaseLink;
import com.shopping.bean.ShoppingTrolley;

public class ShoppingTrolleydao {
	
	public boolean insertShoppingTrolley(String username, String id, int amount){
		boolean result;
		try
		{
			DatabaseLink db = new DatabaseLink();
			Connection conn=db.getConn();
			PreparedStatement pstate1 = conn.prepareStatement("select * from shoppingTrolley where username=? and id=?");
			PreparedStatement pstate2 = conn.prepareStatement("update shoppingTrolley set amount=? where username=? and id=?");
			PreparedStatement pstate3 = conn.prepareStatement("insert into shoppingTrolley(username,id,amount) values (?,?,?)");
			pstate1.setNString(1, username);
			pstate2.setNString(2, username);
			pstate3.setNString(1, username);
			pstate1.setNString(2, id);
			ResultSet rs = pstate1.executeQuery();
			if(rs.next())
			{
				pstate2.setInt(1, rs.getInt("amount")+amount);
				pstate2.setNString(3, id);
				pstate2.executeUpdate();
			}
			else
			{
				pstate3.setNString(2, id);
				pstate3.setInt(3, amount);
				pstate3.executeUpdate();
			}		
			
			result = true;
		    conn.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
			result = false;
		}
		return result;
	}
	
	public boolean deleteAShoppingTrolley(String username, String id){
		boolean result;
		try
		{
			DatabaseLink db = new DatabaseLink();
			Connection conn=db.getConn();
			PreparedStatement pstate =conn.prepareStatement("delete from shoppingTrolley where username=? and id = ?");
			pstate.setNString(1, username);
			pstate.setNString(2, id);
			pstate.executeUpdate();
			result = true;
		    conn.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
			result = false;
		}
		return result;
	}
	
	public boolean deleteMoreShoppingTrolley(String username, String id[ ]){
		boolean result;
		try
		{
			DatabaseLink db = new DatabaseLink();
			Connection conn=db.getConn();
			PreparedStatement pstate =conn.prepareStatement("delete from shoppingTrolley where username=? and id = ?");
			pstate.setNString(1, username);
			for(int i = 0;  i<id.length;  i++)
			{
				pstate.setNString(2, id[ i ]);
				pstate.executeUpdate();
			}
			result = true;
		    conn.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
			result = false;
		}
		return result;
	}
	
	public  List<ShoppingTrolley> showShoppingTrolley(String username) throws Exception{
		List<ShoppingTrolley> shoppingTrolleyList=new ArrayList<ShoppingTrolley>();
		try {
			DatabaseLink db = new DatabaseLink();
		    Connection conn = db.getConn();
			PreparedStatement pstate1 =conn.prepareStatement("select * from shoppingtrolley where username=? order by id");
			PreparedStatement pstate2 =conn.prepareStatement("select * from goods where id=?");
			pstate1.setNString(1, username);
			ResultSet rs1 = pstate1.executeQuery();
			while(rs1.next()){ 
				ShoppingTrolley shoppingTrolley =new ShoppingTrolley(username, null, null, null, 0, 0, 0);
				shoppingTrolley.setId(rs1.getString("id"));
				shoppingTrolley.setAmount(rs1.getInt("amount"));
				pstate2.setNString(1, rs1.getString("id"));
				ResultSet rs2 = pstate2.executeQuery();
				rs2.next();
				shoppingTrolley.setName(rs2.getString("name"));
				shoppingTrolley.setPicture(rs2.getString("picture"));
				shoppingTrolley.setPrice(rs2.getFloat("price"));
				shoppingTrolley.setTotal(rs1.getInt("amount")*rs2.getFloat("price"));
		        shoppingTrolleyList.add(shoppingTrolley);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return shoppingTrolleyList;
	}
	
	public  float getTotal(String username) throws Exception{
		float total = 0;
		try {
			DatabaseLink db = new DatabaseLink();
		    Connection conn = db.getConn();
			PreparedStatement pstate1 =conn.prepareStatement("select * from shoppingtrolley where username=? order by id");
			PreparedStatement pstate2 =conn.prepareStatement("select * from goods where id=?");
			pstate1.setNString(1, username);
			ResultSet rs1 = pstate1.executeQuery();
			while(rs1.next()){ 
				pstate2.setNString(1, rs1.getString("id"));
				ResultSet rs2 = pstate2.executeQuery();
				rs2.next();
				BigDecimal b1 = new BigDecimal(Float.toString(total));   
				BigDecimal b2 = new BigDecimal(Float.toString(rs1.getInt("amount")*rs2.getFloat("price")));   
				total = b1.add(b2).floatValue();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return total;
	}

}
