package com.shopping.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.shopping.DbUtil.DatabaseLink;
import com.shopping.bean.*;
import java.math.BigDecimal;
public class Orderdao {
	
	public int insertOrder(String username, String id[], int amount[] ){
		int ordernumber = 0;
		try
		{
			DatabaseLink db = new DatabaseLink();
			Connection conn=db.getConn();		
			Statement state =conn.createStatement();
			ResultSet rs1 = state.executeQuery("select ordernumber from orders order by ordernumber desc");
			if(rs1.next())
			{
				ordernumber = rs1.getInt("ordernumber")+1;
			}
			else
			{
				ordernumber = 1;
			}
			PreparedStatement pstate = conn.prepareStatement("insert into orders(ordernumber,username,id,amount) values (?,?,?,?)");
			pstate.setInt(1, ordernumber);
			pstate.setNString(2, username);
			for(int i = 0; i<id.length; i++)
			{
				pstate.setNString(3, id[i]);
				pstate.setInt(4, amount[i]);
				pstate.executeUpdate();
			}
		    conn.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return ordernumber;
	}
	
	public  List<Order> showOrder(int ordernumber) {
		List<Order> orderList=new ArrayList<Order>();
		if(ordernumber ==0)
		{
			return orderList;
		}
		else
		{
			try {
				DatabaseLink db = new DatabaseLink();
			    Connection conn = db.getConn();
			    PreparedStatement pstate1 =conn.prepareStatement("select * from orders where ordernumber=? order by id ");
				PreparedStatement pstate2 =conn.prepareStatement("select * from goods where id=?");
				pstate1.setInt(1, ordernumber);
				ResultSet rs1 = pstate1.executeQuery();
				while(rs1.next()){ 
					Order goods =new Order(null, null, null, null, 0, 0, 0);
					goods.setUsername(rs1.getString("username"));
					goods.setId(rs1.getString("id"));
					goods.setAmount(rs1.getInt("amount"));
					pstate2.setNString(1, rs1.getString("id"));
					ResultSet rs2 = pstate2.executeQuery();
					rs2.next();
					goods.setName(rs2.getString("name"));
					goods.setPicture(rs2.getString("picture"));
					goods.setPrice(rs2.getFloat("price"));
					goods.setTotal(rs1.getInt("amount")*rs2.getFloat("price"));
					orderList.add(goods);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return orderList;
	}
	
	public int getGoodsamount(int ordernumber){
		int goodsamount = 0;
		try {
			DatabaseLink db = new DatabaseLink();
		    Connection conn = db.getConn();
			PreparedStatement pstate =conn.prepareStatement("select * from orders where ordernumber=? ");
			pstate.setInt(1, ordernumber);
			ResultSet rs = pstate.executeQuery();
			rs.last();
			goodsamount = rs.getRow();
			System.out.println(goodsamount);
			rs.beforeFirst();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return goodsamount;
	}
		
	public  float getOrderTotal(int ordernumber) {
		float ordertotal = 0;
		if(ordernumber ==0)
		{
			return ordertotal;
		}
		else
		{
			try {
				DatabaseLink db = new DatabaseLink();
			    Connection conn = db.getConn();
				PreparedStatement pstate1 =conn.prepareStatement("select * from orders where ordernumber=? order by id ");
				PreparedStatement pstate2 =conn.prepareStatement("select * from goods where id=?");
				pstate1.setInt(1, ordernumber);
				ResultSet rs1 = pstate1.executeQuery();
				while(rs1.next()){ 
					pstate2.setNString(1, rs1.getString("id"));
					ResultSet rs2 = pstate2.executeQuery();
					rs2.next();
					
					
					BigDecimal b1 = new BigDecimal(Float.toString(ordertotal));   
					BigDecimal b2 = new BigDecimal(Float.toString(rs1.getInt("amount")*rs2.getFloat("price")));   
					ordertotal = b1.add(b2).floatValue();
					//System.out.println(ordertotal);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return ordertotal;
		}
	}
	
	public  int[ ] getAllOrderNumber(String username) {
		int i = 0;
			try {
				DatabaseLink db = new DatabaseLink();
			    Connection conn = db.getConn();
				PreparedStatement pstate =conn.prepareStatement("select * from orders where username=? order by ordernumber ");
				pstate.setNString(1, username);
				ResultSet rs = pstate.executeQuery();
				rs.last();
				int row = rs.getRow();
				rs.beforeFirst();
				int orderNumberList[ ] = new int[row];
				int orderNumber = 0;
				while(rs.next()){
					if(rs.getInt("ordernumber") > orderNumber)
					{
						orderNumber = rs.getInt("ordernumber");
						orderNumberList[ i ] = orderNumber;
						i++;
					}
				}
				return orderNumberList;
			} catch (Exception e) {
				e.printStackTrace();
				return null ;
			}
		}
	
	public  List<AllOrder> showAllOrder(int orderNumberList[]) {
		List<AllOrder> allOrderList = new ArrayList<AllOrder>();
		for(int i = 0; i<orderNumberList.length&&orderNumberList[ i ] != 0; i++)
		{
			AllOrder allOrder = new AllOrder();
			allOrder.setOrdernumber(orderNumberList[ i ]);
			allOrder.setGoodsamount(getGoodsamount(orderNumberList[ i ]));
			allOrder.setOrdertotal(getOrderTotal(orderNumberList[ i ]));
			allOrder.setOrderlist(showOrder(orderNumberList[ i ]));
			allOrderList.add(allOrder);
		}
		return allOrderList;
	}

}