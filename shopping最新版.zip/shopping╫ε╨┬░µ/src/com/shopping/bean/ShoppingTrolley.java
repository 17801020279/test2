package com.shopping.bean ;

public class ShoppingTrolley {
	
	private String username;
	private String id;
	private String name;
	private String picture;
	private int amount;
	private float price;
	private float total;
	
	public ShoppingTrolley(String username, String id, String name, String picture, int amount, float price, float total) {
		super();
		this.username = username;
		this.id = id;
		this.name = name;
		this.picture = picture;
		this.amount = amount;
		this.price = price;
		this.total = total;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}	
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public float getTotal() {
		return total;
	}
	public void setTotal(float total) {
		this.total = total;
	}
}
