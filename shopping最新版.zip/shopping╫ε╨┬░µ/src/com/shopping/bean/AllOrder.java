package com.shopping.bean;

import java.util.ArrayList;
import java.util.List;

public class AllOrder {
	private int ordernumber;
	private int goodsamount;
	private float ordertotal;
    private List<Order> orderlist= new ArrayList<Order>();
    
    
	public AllOrder(){
		super();
	}
	
	public AllOrder(int ordernumber, int ordertotal, List<Order> orderlist) {
		super();
		this.ordernumber = ordernumber;
		this.ordertotal = ordertotal;
		this.orderlist = orderlist;
	}
	
	public int getOrdernumber() {
		return ordernumber;
	}
	public void setOrdernumber(int ordernumber) {
		this.ordernumber = ordernumber;
	}
	public int getGoodsamount() {
		return goodsamount;
	}
	public void setGoodsamount(int goodsamount) {
		this.goodsamount = goodsamount;
	}
	public float getOrdertotal() {
		return ordertotal;
	}
	public void setOrdertotal(float ordertotal) {
		this.ordertotal = ordertotal;
	}
	public List<Order> getOrderlist() {
		return orderlist;
	}
	public void setOrderlist(List<Order> orderlist) {
		this.orderlist = orderlist;
	}
}
