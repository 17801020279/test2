package com.shopping.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.bean.Goods;
import com.shopping.service.ShowGoodsService;

@SuppressWarnings("serial")
public class ShowBookServlet extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp)
     throws ServletException, IOException {
	req.setCharacterEncoding("utf-8");    //���봦��
	ShowGoodsService  showBookService =new ShowGoodsService();
	 List<Goods> bookList = new ArrayList<Goods>();    
	 try {
		 bookList=showBookService.showBookList();
		 req.setAttribute("bookList", bookList);
	} catch (Exception e) {
		e.printStackTrace();
	}
	req.getRequestDispatcher("book.jsp").forward(req, resp);		
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doGet(req, resp);
	}
}
