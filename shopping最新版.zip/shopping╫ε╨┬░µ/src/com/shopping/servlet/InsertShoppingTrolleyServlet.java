package com.shopping.servlet;

import java.io.IOException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.bean.*;
import com.shopping.service.ShowShoppingTrolleyService;

@SuppressWarnings("serial")
public class InsertShoppingTrolleyServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");    //���봦��
		String username=(String) req.getSession().getAttribute("username");
		String id=req.getParameter("id");
		int amount = Integer.parseInt(req.getParameter("amount"));
		ShowShoppingTrolleyService insertShoppingTrolleyService =new ShowShoppingTrolleyService();
		boolean result=insertShoppingTrolleyService.insertShoppingTrolley(username, id, amount);
		if (result) {
			req.getRequestDispatcher("showShoppingTrolley.action").forward(req, resp);	
		}else {
			req.getRequestDispatcher("showDetail.action").forward(req, resp);	
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doGet(req, resp);
	}
}
