package com.shopping.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.service.ShowShoppingTrolleyService;

@SuppressWarnings("serial")
public class DeleteShoppingTrolleyServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		   req.setCharacterEncoding("utf-8");    //���봦��
		   ShowShoppingTrolleyService delShoppingTrolleyService =new ShowShoppingTrolleyService(); //����service
		   boolean del;
		   String username=(String) req.getSession().getAttribute("username");
		   String id=req.getParameter("id");
		   try {
		   del=delShoppingTrolleyService.deleteAShoppingTrolley(username, id);
		   if (del) {
				req.getRequestDispatcher("delShoppingTrolley_success.jsp").forward(req, resp);
			}else {
				req.getRequestDispatcher("delShoppingTrolley_fail.jsp").forward(req, resp);
			}
			
			} catch (Exception e) {
				req.getRequestDispatcher("delCourseTable_fail.jsp").forward(req, resp);
			        }
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
