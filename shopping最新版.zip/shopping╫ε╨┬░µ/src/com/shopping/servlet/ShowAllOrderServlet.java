package com.shopping.servlet;

import java.io.IOException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.bean.*;
import com.shopping.service.*;

@SuppressWarnings("serial")
public class ShowAllOrderServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
	throws ServletException, IOException {
               req.setCharacterEncoding("utf-8");    //���봦��
       		   String username=(String) req.getSession().getAttribute("username");
       		   ShowOrderService  showOrderService=new ShowOrderService();
      		   try {
      			   int orderNumberList[ ] = showOrderService.getAllOrderNumber(username);
          		   List<AllOrder> allOrderList = showOrderService.showAllOrder(orderNumberList);
          		   req.setAttribute("allOrderList", allOrderList);	   
          		   //AllOrder order = allOrderList.get(0);
          		   //System.out.println(order.getOrderNumber());
          		   //System.out.println(order.getOrderTotal());
				} catch (Exception e) {
					e.printStackTrace();
				}
      		   req.getRequestDispatcher("showallorder.jsp").forward(req, resp);	
      		   }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
    	throws ServletException, IOException {
        this.doGet(req, resp);
        }
}
