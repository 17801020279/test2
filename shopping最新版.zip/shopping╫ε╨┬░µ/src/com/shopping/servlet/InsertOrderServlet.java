package com.shopping.servlet;

import java.io.IOException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.bean.*;
import com.shopping.service.*;

@SuppressWarnings("serial")
public class InsertOrderServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");    //���봦��
		int ordernumber = 0;
		ShowOrderService  showOrderService=new ShowOrderService();
		ShowShoppingTrolleyService ShoppingTrolleyService =new ShowShoppingTrolleyService();
		String username=(String) req.getSession().getAttribute("username");
		String goodsid = req.getParameter("goodsid");
		String number = req.getParameter("goodsnumber");
		String[] id = goodsid.split(",");
		String goodsamount[] = number.split(",");
		int amount[] = new int[goodsamount.length];
		for(int i=0; i<goodsamount.length;i++){
			amount[ i ] = Integer.parseInt(goodsamount[ i ]);
		}		
		try {
			ordernumber=showOrderService.insertOrder(username, id, amount);
			System.out.println("�µ��ɹ�");
			ShoppingTrolleyService.deleteMoreShoppingTrolley(username, id);
		 	} catch (Exception e) {
				System.out.println("�µ�ʧ��");
				e.printStackTrace();
				req.getRequestDispatcher("showShoppingTrolley.action").forward(req, resp);	
			}
		
		try {
			List<Order> orderList = showOrderService.showOrder(ordernumber);
			float orderTotal = showOrderService.getOrderTotal(ordernumber);
			req.setAttribute("ordernumber", ordernumber);
			req.setAttribute("orderList", orderList);
			req.setAttribute("orderTotal", orderTotal);
			} catch (Exception e) {
				e.printStackTrace();
			}
			req.getRequestDispatcher("showorder.jsp").forward(req, resp);		
	}
		
		
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doGet(req, resp);
	}

}