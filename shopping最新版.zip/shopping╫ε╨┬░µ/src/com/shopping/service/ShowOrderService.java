package com.shopping.service;

import java.util.*;

import com.shopping.bean.AllOrder;
import com.shopping.bean.Order;
import com.shopping.dao.Orderdao;

public class ShowOrderService {
	public  List<Order> showOrder(int ordernumber) throws Exception{
		Orderdao showOrderdao=new Orderdao();
		List<Order> orderList = showOrderdao.showOrder(ordernumber);
		return orderList;
	}
	
	public  float getOrderTotal(int ordernumber) throws Exception {
		Orderdao showOrderdao=new Orderdao();
		float orderTotal=0;
		orderTotal=showOrderdao.getOrderTotal(ordernumber);
		return orderTotal;
	}
	
	public int insertOrder(String username, String id[],  int amount[ ]){
		Orderdao showOrderdao=new Orderdao();
		int ordernumber=showOrderdao.insertOrder(username, id,amount);
		return ordernumber;	
	}
	
	public int[ ] getAllOrderNumber(String username){
		Orderdao showOrderdao=new Orderdao();
		int orderNumberList[ ]=showOrderdao.getAllOrderNumber(username);
		return orderNumberList;
	}
	
	public  List<AllOrder> showAllOrder(int orderNumberList[]) throws Exception{
		Orderdao showOrderdao=new Orderdao();
		List<AllOrder> allOrderList = showOrderdao.showAllOrder(orderNumberList);
		return allOrderList;
	}

}
