package com.shopping.service;

import java.util.List;

import com.shopping.bean.ShoppingTrolley;
import com.shopping.dao.ShoppingTrolleydao;

public class ShowShoppingTrolleyService {

	public List<ShoppingTrolley> showShoppingTrolley(String username) throws Exception {
		ShoppingTrolleydao showShoppingTrolleydao  =new ShoppingTrolleydao();
		List<ShoppingTrolley> showShoppingTrolleyList=showShoppingTrolleydao.showShoppingTrolley(username);
		return showShoppingTrolleyList;
	}
	
	public  float getTotal(String username) throws Exception {
		ShoppingTrolleydao showShoppingTrolleydao  =new ShoppingTrolleydao();
		float total=0;
		total=showShoppingTrolleydao.getTotal(username);
		return total;
	}
	
	public boolean insertShoppingTrolley(String username, String id, int amount){
		ShoppingTrolleydao showShoppingTrolleydao  =new ShoppingTrolleydao();
		boolean result=showShoppingTrolleydao.insertShoppingTrolley(username, id, amount);
		return result;
	
	}
	
	public boolean deleteAShoppingTrolley(String username, String id){
		ShoppingTrolleydao showShoppingTrolleydao  =new ShoppingTrolleydao();
		boolean result=showShoppingTrolleydao.deleteAShoppingTrolley(username, id);
		return result;
	}
	
	public boolean deleteMoreShoppingTrolley(String username, String id[ ]){
		ShoppingTrolleydao showShoppingTrolleydao  =new ShoppingTrolleydao();
		boolean result=showShoppingTrolleydao.deleteMoreShoppingTrolley(username, id);
		return result;
	}

}
