package com.shopping.dao;
import java.sql.*;

import com.shopping.DbUtil.DatabaseLink;

public class Logindao {
	
	public String checklogin(String username){
		String password = null;
		try
		{
			DatabaseLink db = new DatabaseLink();
			Connection conn=db.getConn();
			PreparedStatement pstate =conn.prepareStatement("select * from consumer  where username =?");
			pstate.setNString(1, username);
			ResultSet rs = pstate.executeQuery();
			if(rs.next())
			{
				password = rs.getString(2);
			}else if(password==null){
				password = "";
			}
		    rs.close();
		    conn.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return password;
	}

}
