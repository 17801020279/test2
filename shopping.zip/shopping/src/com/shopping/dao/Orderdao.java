package com.shopping.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.shopping.DbUtil.DatabaseLink;
import com.shopping.bean.Order;
public class Orderdao {
	
	public boolean insertOrder(String username, String id[] ){
		boolean result = false;
		try
		{
			DatabaseLink db = new DatabaseLink();
			Connection conn=db.getConn();	
			PreparedStatement pstate1 = conn.prepareStatement("select * from shoppingTrolley where username=?");
			pstate1.setNString(1, username);
			ResultSet rs1 = pstate1.executeQuery();
			if(rs1.next())
			{
				PreparedStatement pstate = conn.prepareStatement("insert into orders(username,id,amount) values (?,?,?)");
				pstate.setNString(1, username);
				for(int i = 0; i<id.length; i++)
				{
				pstate.setNString(2, id[i]);
				pstate.executeUpdate();
			     }
			    conn.close();
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
			result = false;
		}
		return result;
			
	}	
	
	public  List<Order> showOrder(String username) throws Exception{
		List<Order> orderList=new ArrayList<Order>();
		try {
			DatabaseLink db = new DatabaseLink();
		    Connection conn = db.getConn();
		    PreparedStatement pstate1 =conn.prepareStatement("select * from orders where username=? ");
			PreparedStatement pstate2 =conn.prepareStatement("select * from goods where id=?");
			pstate1.setNString(1, username);
			ResultSet rs1 = pstate1.executeQuery();
			while(rs1.next()){ 
				Order goods =new Order();
				goods.setUsername(rs1.getString("username"));
				goods.setId(rs1.getString("id"));
				goods.setAmount(rs1.getInt("amount"));
				pstate2.setNString(1, rs1.getString("id"));
				ResultSet rs2 = pstate2.executeQuery();
				rs2.next();
				goods.setName(rs2.getString("name"));
				goods.setPicture(rs2.getString("picture"));
				goods.setPrice(rs2.getFloat("price"));
				goods.setTotal(rs1.getInt("amount")*rs2.getFloat("price"));
				orderList.add(goods);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return orderList;
	}
	
	public  float getOrderTotal(String username) throws Exception{
		float ordertotal = 0;
		try {
			DatabaseLink db = new DatabaseLink();
		    Connection conn = db.getConn();
			PreparedStatement pstate1 =conn.prepareStatement("select * from orders where username=? ");
			PreparedStatement pstate2 =conn.prepareStatement("select * from goods where id=?");
			pstate1.setNString(1, username);
			ResultSet rs1 = pstate1.executeQuery();
			while(rs1.next()){ 
				pstate2.setNString(1, rs1.getString("id"));
				ResultSet rs2 = pstate2.executeQuery();
				rs2.next();
				ordertotal = ordertotal + rs1.getInt("amount")*rs2.getFloat("price");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ordertotal;
	}
	
}