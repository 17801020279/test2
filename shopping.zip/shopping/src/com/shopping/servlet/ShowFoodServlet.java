package com.shopping.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.bean.Goods;
import com.shopping.service.ShowGoodsService;

@SuppressWarnings("serial")
public class ShowFoodServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		ShowGoodsService  showFoodService =new ShowGoodsService();
		 List<Goods> foodList = new ArrayList<Goods>();    
		 try {
			 foodList=showFoodService.showFoodList();
			 req.setAttribute("foodList", foodList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		req.getRequestDispatcher("food.jsp").forward(req, resp);		
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
