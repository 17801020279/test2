package com.shopping.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.bean.Consumer;
import com.shopping.service.LoginService;

@SuppressWarnings("serial")
public class LoginServlet  extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");    //���봦��
		LoginService loginService=new LoginService();
		String dbpassword ;
		String username=req.getParameter("username");//����ҳ���ֵ
		String password=req.getParameter("password");
		Consumer consumer =new Consumer(username, password);
		try {
			dbpassword=loginService.checklogin(username);
		    if (dbpassword==null) {
		    	   req.setAttribute("err","���ݿ�����ʧ�ܣ�����") ;
		    	   req.getRequestDispatcher("login.jsp").forward(req, resp);
			}else if (dbpassword.equals("")) {
		    	 req.setAttribute("err","�û��������ڣ�����") ;
		    	 req.getRequestDispatcher("login.jsp").forward(req, resp);
			}else if (dbpassword!=null) {
		    		    String dbpw=dbpassword;
		    		    if (password.equals(dbpw)) {
		    			req.getSession().setAttribute("username", consumer.getUsername());
		    			req.getSession().setAttribute("password", consumer.getPassword());
		    			req.getRequestDispatcher("/showBook.action").forward(req, resp);
					  }else {
						  req.setAttribute("err","������󣡣���") ;
						  req.getRequestDispatcher("login.jsp").forward(req, resp);
					}
			    }else {
			    req.setAttribute("err","�û��������ڣ�����") ;
				req.getRequestDispatcher("login.jsp").forward(req, resp);
			   }
		 	} catch (Exception e) {
				e.printStackTrace();
			}
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
