package com.shopping.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.shopping.bean.Order;
import com.shopping.service.ShowOrderService;

@SuppressWarnings("serial")
public class ShowOrderServlet extends HttpServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
	throws ServletException, IOException {
               req.setCharacterEncoding("utf-8");    //���봦��
               String username=(String) req.getSession().getAttribute("username");
               ShowOrderService  showOrderService=new ShowOrderService();
               List<Order> orderList= new ArrayList<Order>();
            	   try {
					orderList=showOrderService.showOrder(username);
				 	req.setAttribute("orderList", orderList);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
	               try {
	                    	float ordertotal;
	                    	ordertotal=showOrderService.getOrderTotal(username);
	                        req.setAttribute("ordertotal", ordertotal);
	                  } catch (Exception e) {
	                          e.printStackTrace();
	                           }
	                 req.getRequestDispatcher("/showorder.jsp").forward(req, resp);	
	              }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
    	throws ServletException, IOException {
        this.doGet(req, resp);
        }
}
