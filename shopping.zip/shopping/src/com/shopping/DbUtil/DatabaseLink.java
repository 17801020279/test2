package com.shopping.DbUtil;
import java.sql.*;

public class DatabaseLink {
	Connection conn;
	public DatabaseLink()
	{
		String url="jdbc:mysql://localhost:3306/shopping";
		String user="root";
		String password="root";
		conn = null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(url,user,password);
		}
		catch (Exception e)
		{
			conn = null;
		}
	}
	
	public Connection getConn()
	{
		return conn;
	}
	
	public void freeCon() throws SQLException
	{
		if(conn != null)
		{
			conn.close();
		}
	}
}
