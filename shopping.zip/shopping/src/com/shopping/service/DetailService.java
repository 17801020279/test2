package com.shopping.service;


import java.util.List;

import com.shopping.bean.Goods;
import com.shopping.dao.Showdao;

public class DetailService {

	public List<Goods> showDetail(String id) throws Exception {
		Showdao showDao=new Showdao();
		List<Goods>  goodsList=showDao.showDetail(id);
		return goodsList;
	}
	

}
