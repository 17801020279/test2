package com.shopping.service;

import java.util.List;

import com.shopping.bean.Order;
import com.shopping.dao.Orderdao;

public class ShowOrderService {
	public  List<Order> showOrder(String username) throws Exception{
		Orderdao showOrderdao=new Orderdao();
		List<Order> showShoppingTrolleyList=showOrderdao.showOrder(username);
		return showShoppingTrolleyList;
	}
	
	public  float getOrderTotal(String username) throws Exception {
		Orderdao showOrderdao=new Orderdao();
		float ordertotal=0;
		ordertotal=showOrderdao.getOrderTotal(username);
		return ordertotal;
	}
	
	public boolean insertOrder(String username, String id[] ){
		Orderdao showOrderdao=new Orderdao();
		boolean result=showOrderdao.insertOrder(username, id);
		return result;
	
	}

}
