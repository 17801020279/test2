package com.shopping.service;

import java.util.List;

import com.shopping.bean.Goods;
import com.shopping.dao.Showdao;


public class ShowGoodsService {
	public  List<Goods> showBookList() throws Exception{
		Showdao showDao=new Showdao();
		List<Goods>  bookList=showDao.showBookList();
		return bookList;
}

	public List<Goods> showFoodList() throws Exception {
		Showdao showDao=new Showdao();
		List<Goods>  foodList=showDao.showFoodList();
		return foodList;
	}

}
