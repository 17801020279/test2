package com.shopping.service;
import com.shopping.dao.Logindao;

/**
 *  ��¼
 * @author Xindy
 *
 */

public class LoginService {
		public String checklogin(String username) throws Exception{
			Logindao loginDao=new Logindao();
			return loginDao.checklogin(username);
		}

}
